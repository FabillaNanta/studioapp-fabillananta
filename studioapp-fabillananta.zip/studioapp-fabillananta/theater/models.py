from django.utils.translation import gettext_lazy as _
from django.db import models


class Task(models.Model):
    # define status choices/options
    class TaskStatus(models.TextChoices):
        STUDIO1 = 'Studio(1)', _('Studio 1')
        STUDIO2 = 'Studio(2)', _('Studio 2')
        STUDIO3 = 'Studio(3)', _('Studio 3')
    
    # define columns
    title = models.CharField(max_length=100)
    description = models.TextField()
    status = models.CharField(
        max_length=20,
        choices=TaskStatus.choices,
        default=TaskStatus.STUDIO1
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        # define table name
        db_table = 'tasks'

from theater.models import Task
sampletask1 = Task()
sampletask1.title = "Add another movie"
sampletask1.description = "To add another movie schedule, you can simply click the 'edit' button on the 'action' column or click the 'add a movie schedule' button above"
sampletask1.save()