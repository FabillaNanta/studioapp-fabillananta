from django.utils.translation import gettext_lazy as _
from django.db import models


class Task(models.Model):
    # define status choices/options
    class TaskMovie(models.TextChoices):
        MARVEL = 'SPIDERMAN', _('Spider-Man: No Way Home')
        CLOUD = 'KINGSMAN', _('KINGSMAN')
        ENCANTO = 'ENCANTO', _('ENCANTO')
    
    class TaskStudio(models.TextChoices):
        STUDIO1 = 'STUDIO1', _('STUDIO 1 (2A)')
        STUDIO1A = 'STUDIO1A', _('STUDIO 1 (3A)')
        STUDIO2 = 'STUDIO2', _('STUDIO 2 (4B)')
        STUDIO3 = 'STUDIO3', _('STUDIO 3 (7E)')
        STUDIO4 = 'STUDIO4', _('STUDIO 4 (6D)')

    
    # define columns
    name = models.CharField(max_length=100)
    studio = models.CharField(
        max_length=20,
        choices=TaskStudio.choices,
        default=TaskStudio.STUDIO3
    )
    movie = models.CharField(
        max_length=20,
        choices=TaskMovie.choices,
        default=TaskMovie.MARVEL
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        # define table name
        db_table = 'order'

from ticketing.models import Task
sampletask1 = Task()
sampletask1.name = "Fabilla"
sampletask1.studio = "STUDIO 1 (2A)"
sampletask1.save()